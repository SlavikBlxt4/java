package com.example.utils;

public class Conectar {
    public static final String USER = "postgres";
    public static final String PASSWORD = "postgres";
    public static final boolean ssl = false;
}
