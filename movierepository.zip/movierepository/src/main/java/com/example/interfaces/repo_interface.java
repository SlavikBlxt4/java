package com.example.interfaces;

import java.util.List;

import com.example.Repositories.Pelicula;


public interface repo_interface {
    List<Pelicula> getMovies();
 }
 